package com.ctreber.aclib;

import java.awt.Image;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.WindowConstants;

import com.ctreber.aclib.image.ico.BitmapDescriptor;
import com.ctreber.aclib.image.ico.ICOFile;

/**
 * AC.lib ICO demo application. Uses the ICO SPI.
 * @author &copy; 2004 Christian Treber, ct@ctreber.com (08.08.2004)
 */
public class DemoAppSPI {
    /** For main() only. */
    private int _frames;

    /**
     * Main!
     * @param pArgs
     *            CLI args.
     * @throws IOException
     */
    public static void main(final String[] pArgs) throws IOException {
        new DemoAppSPI().run(pArgs);
    }

    /**
     * @param pArgs
     *            CLI args.
     * @throws IOException
     */
    private void run(final String[] pArgs) throws IOException {
        if (pArgs.length == 0) {
            System.err
                    .println("Usage: aclibico.sh <fileName:string> [{, <fileName:string>}]\n"
                            + "fileName can be an URL, too");
            System.exit(1);
        }

        for (int lArgNo = 0; lArgNo < pArgs.length; lArgNo++) {
            final String lFileName = pArgs[lArgNo];

            ICOFile lICOFile = null;
            try {
                // @PMD:REVIEWED:AvoidInstantiatingObjectsInLoops: by Chris on
                // 06.03.06 11:05
                final URL pURL = new URL(lFileName);
                // @PMD:REVIEWED:AvoidInstantiatingObjectsInLoops: by Chris on
                // 06.03.06 11:09
                lICOFile = new ICOFile(pURL);
            } catch (MalformedURLException e) {
                // @PMD:REVIEWED:AvoidInstantiatingObjectsInLoops: by Chris on
                // 06.03.06 10:36
                lICOFile = new ICOFile(lFileName);
            }

            for (int lEntryNo = 0; lEntryNo < lICOFile.getDescriptors().size(); lEntryNo++) {
                addEntry(lFileName, lICOFile, lEntryNo);
            }
        }
    }

    /**
     * @param pFileName
     *            The file name.
     * @param pICOFile
     *            The ICO file.
     * @param pEntryNo
     *            The entry number.
     */
    private void addEntry(final String pFileName, final ICOFile pICOFile,
            final int pEntryNo) {
        final BitmapDescriptor lEntry = pICOFile.getDescriptor(pEntryNo);
        System.out.println(getCaption(pFileName, pEntryNo, lEntry));
        final Image lImage = lEntry.getImageRGB();
        if (lImage != null) {
            final JFrame lFrame = new JFrame(getCaption(pFileName, pEntryNo,
                    lEntry));
            lFrame.getContentPane().add(new JButton(new ImageIcon(lImage)));
            lFrame.setSize(500, 200);
            lFrame.setVisible(true);
            _frames++;
            lFrame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
            lFrame.addWindowListener(new WindowAdapter() {
                public void windowClosed(final WindowEvent pEvent) {
                    windowClose();
                }
            });
        } else {
            System.err.println("Could not create RGB image for image no. "
                    + (1 + pEntryNo));
        }
    }

    private void windowClose() {
        _frames--;
        if (_frames <= 0) {
            System.out.println("Bye!");
            System.exit(0);
        }
    }

    private static String getCaption(final String pFileName,
            final int pEntryNo, final BitmapDescriptor pEntry) {
        return pFileName + ": " + "Entry no. " + (1 + pEntryNo) + ", "
                + pEntry.getWidth() + " x " + pEntry.getHeight() + ", "
                + pEntry.getBPP() + " BPP";
    }

}
