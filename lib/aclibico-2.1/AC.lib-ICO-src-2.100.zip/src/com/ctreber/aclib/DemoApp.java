package com.ctreber.aclib;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.WindowConstants;
import javax.swing.border.EtchedBorder;

import org.apache.log4j.Logger;

import com.ctreber.aclib.image.ico.BitmapDescriptor;
import com.ctreber.aclib.image.ico.ICOFile;

/**
 * AC.lib ICO demo application. Loads a single ICO file or searches a directory
 * recursively for ICO files.
 * @author &copy; 2004 Christian Treber, ct@ctreber.com
 */
public class DemoApp {
    private static final Logger LOG = Logger.getLogger(DemoApp.class);

    /**
     * See class comment.
     * @param pArgs
     *            CLI args.
     */
    public static void main(final String[] pArgs) {
        new DemoApp().run(pArgs);
    }

    /**
     * @param pArgs
     *            CLI args.
     */
    private void run(final String[] pArgs) {
        if (pArgs.length == 0) {
            JOptionPane.showMessageDialog(null,
                    "Usage: java -jar aclibico.jar {<ICO file|subdir>}",
                    "AC.lib ICO - Usage", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        final JFrame lFrame = createMainWindow();
        final JPanel lICOFilesPanel = createICOFilesPanel();
        final JScrollPane lScroll = new JScrollPane(lICOFilesPanel);
        lFrame.getContentPane().add(lScroll);

        final List lICOFiles = getICOFileList(pArgs);
        Collections.sort(lICOFiles);
        final Iterator lIt = lICOFiles.iterator();
        while (lIt.hasNext()) {
            final File lFile = (File) lIt.next();

            final ICOFile lICOFile = obtainICOFile(lFile);
            if (lICOFile == null) {
                addErrorMessage(lICOFilesPanel, lFile);
                continue;
            }

            addICOPanel(lICOFilesPanel, lICOFile);
        }

        lFrame.pack();
        lFrame.setVisible(true);
    }

    /**
     * @param pArgs
     *            The files/directories to add.
     * @return The list of file names.
     */
    private List getICOFileList(final String[] pArgs) {
        final List lICOFiles = new ArrayList();
        for (int lArgNo = 0; lArgNo < pArgs.length; lArgNo++) {
            lICOFiles.addAll(getFiles(pArgs[lArgNo]));
        }
        return lICOFiles;
    }

    /**
     * @return The main window.
     */
    private JFrame createMainWindow() {
        final JFrame lFrame = new JFrame();
        lFrame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        lFrame.addWindowListener(new WindowAdapter() {
            public void windowClosed(final WindowEvent pEvent) {
                System.exit(0);
            }
        });
        return lFrame;
    }

    /**
     * Create and add a panel containing all icons in the ICO file.
     * @param pParent
     *            The parent to add the panel to.
     * @param pICOFile
     *            The ICO file.
     */
    private void addICOPanel(final JPanel pParent, final ICOFile pICOFile) {
        final JPanel lICOFilePanel = createICOFilePanel(pICOFile);
        pParent.add(lICOFilePanel);

        final Iterator lDescIt = pICOFile.getDescriptors().iterator();
        while (lDescIt.hasNext()) {
            final BitmapDescriptor lDescriptor = (BitmapDescriptor) lDescIt
                    .next();

            final Image lImage = createImage(pICOFile, lDescriptor);
            if (lImage == null) {
                continue;
            }

            addBitmap(lICOFilePanel, lDescriptor, lImage);
        }
    }

    /**
     * @param pParent
     *            The parent component.
     * @param pDescriptor
     *            The image descriptor.
     * @param pImage
     *            The image.
     */
    private void addBitmap(final JPanel pParent,
            final BitmapDescriptor pDescriptor, final Image pImage) {
        final JPanel lBitmapsPanel = new JPanel(new FlowLayout());
        final JButton lBitmapButton = new JButton(new ImageIcon(pImage));
        lBitmapsPanel.add(lBitmapButton);

        final JPanel lPnlText = createBitmapText(pDescriptor);
        lBitmapsPanel.add(lPnlText);

        pParent.add(lBitmapsPanel);
    }

    /**
     * @param pParent
     *            The parent component.
     * @param pFile
     *            The file.
     */
    private void addErrorMessage(final JPanel pParent, final File pFile) {
        final JLabel lErrorMessage = new JLabel("Couldn't read ICO file "
                + pFile);
        lErrorMessage.setForeground(Color.RED);
        pParent.add(lErrorMessage);
    }

    /**
     * @return The panel for the ICO images.
     */
    private JPanel createICOFilesPanel() {
        final JPanel lPnlIcons = new JPanel();
        lPnlIcons.setLayout(new BoxLayout(lPnlIcons, BoxLayout.Y_AXIS));
        return lPnlIcons;
    }

    /**
     * @param pICOFile
     *            The ICO file.
     * @param pDescriptor
     *            The image descriptor.
     * @return Image created from lDescriptor, or null if there was a problem.
     */
    private Image createImage(final ICOFile pICOFile,
            final BitmapDescriptor pDescriptor) {
        try {
            return pDescriptor.getImageRGB();
        } catch (RuntimeException e) {
            LOG.error("Could not create image from " + pICOFile + ", "
                    + pDescriptor + " (reason " + e + ")", e);
            return null;
        }
    }

    /**
     * @param pFile
     *            The file.
     * @return ICOFIle create from lFile, or null if an error occured.
     */
    private ICOFile obtainICOFile(final File pFile) {
        try {
            return new ICOFile(pFile.getAbsolutePath());
        } catch (IOException e) {
            LOG.error("Could not read ICO file " + pFile + " (reason: " + e
                    + ")", e);
            return null;
        } catch (RuntimeException e) {
            LOG.error("Encoding problem?", e);
            return null;
        }
    }

    /**
     * @param pDescriptor
     *            The image descriptor.
     * @return A panel with a nice label for the bitmap.
     */
    private JPanel createBitmapText(final BitmapDescriptor pDescriptor) {
        final JPanel lPnlText = new JPanel();
        lPnlText.setLayout(new BoxLayout(lPnlText, BoxLayout.Y_AXIS));
        lPnlText.add(new JLabel("Descriptor: " + pDescriptor));
        lPnlText.add(new JLabel("Header: " + pDescriptor.getHeader()));
        lPnlText.add(new JLabel("Bitmap: " + pDescriptor.getBitmap()));
        return lPnlText;
    }

    /**
     * @param pICOFile
     *            The ICO file.
     * @return A panel with a border and a label for the ICO file.
     */
    private JPanel createICOFilePanel(final ICOFile pICOFile) {
        final JPanel lPnlICOFile = new JPanel();
        lPnlICOFile.setLayout(new BoxLayout(lPnlICOFile, BoxLayout.Y_AXIS));
        lPnlICOFile
                .setBorder(BorderFactory.createTitledBorder(BorderFactory
                        .createEtchedBorder(EtchedBorder.LOWERED), pICOFile
                        .toString()));
        return lPnlICOFile;
    }

    /**
     * @param pFileName
     *            The file name.
     * @return List of ICO files (type: File).
     */
    private List getFiles(final String pFileName) {
        final List lFiles = new ArrayList();
        final File lFile = new File(pFileName);

        if (lFile.isFile()) {
            lFiles.add(lFile);
        } else {
            getFilesRecursively(lFiles, lFile);
        }

        return lFiles;
    }

    private void getFilesRecursively(final List pFiles, final File pFile) {
        final File[] lFiles = pFile.listFiles();
        for (int lFileNo = 0; lFileNo < lFiles.length; lFileNo++) {
            final File lFile = lFiles[lFileNo];
            if (lFile.isFile()
                    && lFile.getName().toLowerCase().endsWith(".ico")) {
                pFiles.add(lFile);
            }
            if (lFile.isDirectory()) {
                getFilesRecursively(pFiles, lFile);
            }
        }
    }

}
